/*
 * Copyright 2012 ZXing authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#import "ZXInvertedLuminanceSource.h"

@interface ZXInvertedLuminanceSource ()

@property (nonatomic, weak) ZXLuminanceSource *delegate;

@end

@implementation ZXInvertedLuminanceSource

- (id)initWithDelegate:(ZXLuminanceSource *)delegate {
  self = [super initWithWidth:delegate.width height:delegate.height];
  if (self) {
    _delegate = delegate;
  }

  return self;
}

- (int8_t *)row:(int)y {
  int8_t *row = [self.delegate row:y];
  for (int i = 0; i < self.width; i++) {
    row[i] = (int8_t) (255 - (row[i] & 0xFF));
  }
  return row;
}

- (int8_t *)matrix {
  int8_t *matrix = [self.delegate matrix];
  int length = self.width * self.height;
  int8_t *invertedMatrix = (int8_t *)malloc(length * sizeof(int8_t));
  for (int i = 0; i < length; i++) {
    invertedMatrix[i] = (int8_t) (255 - (matrix[i] & 0xFF));
  }
  free(matrix);
  return invertedMatrix;
}

- (BOOL)cropSupported {
  return self.delegate.cropSupported;
}

- (ZXLuminanceSource *)crop:(int)left top:(int)top width:(int)aWidth height:(int)aHeight {
  return [[ZXInvertedLuminanceSource alloc] initWithDelegate:[self.delegate crop:left top:top width:aWidth height:aHeight]];
}

- (BOOL)rotateSupported {
  return self.delegate.rotateSupported;
}

/**
 * Returns original delegate ZXLuminanceSource since invert undoes itself
 */
- (ZXLuminanceSource *)invert {
  return self.delegate;
}

- (ZXLuminanceSource *)rotateCounterClockwise {
  return [[ZXInvertedLuminanceSource alloc] initWithDelegate:[self.delegate rotateCounterClockwise]];
}

- (ZXLuminanceSource *)rotateCounterClockwise45 {
  return [[ZXInvertedLuminanceSource alloc] initWithDelegate:[self.delegate rotateCounterClockwise45]];
}

@end
